class TourismPlace {
  String title;
  String Author;
  String description;
  String Harga;
  String Stock;
  String imageAsset;
  List<String> imageUrls;

  TourismPlace({
    required this.title,
    required this.Author,
    required this.description,
    required this.Harga,
    required this.Stock,
    required this.imageAsset,
    required this.imageUrls,
  });
}

var tourismPlaceList = [
  TourismPlace(
      title: 'Acer Predator Helios 300',
      Author: 'Acer',
      description:
          'Laptop gaming dengan prosesor Intel Core i7 dan kartu grafis NVIDIA GeForce RTX 3060, menawarkan keseimbangan antara harga dan performa untuk gamer kelas menengah.',
      Harga: 'Rp8.150.000',
      Stock: '15',
      imageAsset: 'images/Acer Predator Helios 300.jpg',
      imageUrls: [
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSeZNsBkuV-y1lTpNChiuIwLfuSJYARCkvoSw&s',
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR2UrpQxb6tAeQiN12LoKf0g2gn_deRZ-kh8Q&s',
        'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRNdBhawKjAzQsNAv2JbAJsbG_Mi7bLyBACoA&s'
      ]),
  TourismPlace(
    title: 'ASUS ROG Zephyrus G14',
    Author: 'ASUS',
    description:
        'Laptop gaming 14 inci yang ringan dan portabel, dilengkapi dengan prosesor AMD Ryzen 7 6800HS dan kartu grafis AMD Radeon RX 6700S, menawarkan performa tinggi dalam desain kompak.',
    Harga: 'Rp35.999.000',
    Stock: '48',
    imageAsset: 'images/ASUS ROG Zephyrus G14.jpg',
    imageUrls: [
      'https://akcdn.detik.net.id/visual/2020/04/03/c45a125f-ac67-4cc8-b9e9-5da2828f8ccf_169.png?w=400&q=90',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5G5mEYw0MovEatR2SayqBX6CQ5VJ2ieVZE7ePkoOgE0FtKOWb_sT7YWmoLM9Ww5OdBOE&usqp=CAU',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRa58WET8wc1Yt1ha2ZOTxLkY2SCkEL9vBMLYamw7ceo05Mvl-qnsqJerJCNm485unr7fs&usqp=CAU',
    ],
  ),
  TourismPlace(
    title: 'Dell Alienware m15 R6',
    Author: 'Dell',
    description:
        'Laptop gaming dengan layar 15,6 inci QHD, dilengkapi dengan prosesor Intel Core i7-11800H dan kartu grafis NVIDIA GeForce RTX 3060, menawarkan performa tinggi dengan sistem pendinginan canggih.',
    Harga: 'Rp39.400.000',
    Stock: '5',
    imageAsset: 'images/Dell Alienware m15 R6.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpW_xH6JwvpIekq96mZvbb8DsPNJqBArrX8w&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXyEEZMgFNLAfCLvKlOiYeY8quINEZ0gfkBA&s',
      'https://cdn.mos.cms.futurecdn.net/uWoyW5uw652uHWFa8u3aTc-320-80.jpg',
    ],
  ),
  TourismPlace(
    title: 'MSI GE76 Raider',
    Author: 'MSI',
    description:
        'Laptop gaming dengan layar besar 17,3 inci, dilengkapi dengan prosesor Intel Core i9 generasi ke-11 dan kartu grafis NVIDIA GeForce RTX 3080, cocok untuk game AAA dengan performa tinggi.',
    Harga: 'Rp59.999.000',
    Stock: '24',
    imageAsset: 'images/MSI GE76 Raider.jpg',
    imageUrls: [
      'https://asset.msi.com/resize/image/global/product/product_1689753979e1dba069d913a454fa1c27639c1d60ff.png62405b38c58fe0f07fcef2367d8a9ba1/380.png',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSzEETl8Vdycxp6bC9t8mK5xS-IcAhrKa7giEkg0rpkRTQV54SosLArotu4ynFiI_N-Q_U&usqp=CAU',
      'https://http2.mlstatic.com/D_NQ_NP_864510-MLA49567336944_042022-O.webp',
    ],
  ),
  TourismPlace(
    title: 'Razer Blade 15',
    Author: 'Razer',
    description:
        'Laptop gaming dengan desain elegan, dilengkapi dengan prosesor Intel Core i7 atau i9 dan kartu grafis NVIDIA GeForce RTX 3070 atau 3080, menawarkan performa premium dalam bodi ramping.',
    Harga: 'Rp52.990.000',
    Stock: '2',
    imageAsset: 'images/Razer Blade 15.jpg',
    imageUrls: [
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIrzixd25up2MCx8UKac_e1v35S7i7g2i9Vw&s',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSQ0DZbLsrIj-Wf4KjqnzOpgbAJ8y5J58DAWvn1ju0L2z5-xnwqY838M5sFGOKtIJK4IUk&usqp=CAU',
      'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSF2EXouUBKfUgJglFLFjUOwlfdMb_Xd7LLtO98LAG9horSyB0-4utLYEW85XQgsyQybzo&usqp=CAU',
    ],
  ),
];
